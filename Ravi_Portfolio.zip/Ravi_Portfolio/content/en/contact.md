---
title: Contact
featured_image: "images/contact me.jpg"
omit_header_text: true
#description: We'd love to hear from you
#type: page
menu: main

---

You can reach me on....

Platform|URL
---|---
Linkedin|https://www.linkedin.com/in/ravindra-neralla-56ab9217/ 
Youtube|https://www.youtube.com/channel/UCDL2ioR-MLTrtAy3ZRiaX-A 
Github|https://github.com/rneralla1 
Twitter|https://twitter.com/ravindraneralla 




