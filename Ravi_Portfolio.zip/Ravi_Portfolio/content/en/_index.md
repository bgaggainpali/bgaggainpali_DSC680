---
title: "Ravindra Babu Neralla"
featured_image: '/images/data.jpg'
description: "Data Science Portfolio"
---
I am working as Data Engineer and  Data Science enthusiast, my passion is working with data and discovering hidden insights and data Mining.

