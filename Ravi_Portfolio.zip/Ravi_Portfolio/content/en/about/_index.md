---
title: "About"
description: "Ravindra Babu Neralla Data Science Portfolio"
#featured_image: ''
featured_image: '/images/data_science_1.jpg'
---

{{< figure src="/images/linkedin_photo.jpg">}}

My name is _Ravindra Neralla_, working as ETL Developer/Data Engineer since 2005.  I’m passionate about data and I’m interested in getting insights out of data.  Data wrangling/visualization and machine learning are some of the techniques that I am using to achieve this.  I have worked in Banking and Healthcare domains in most of my career.

I have been data science enthusiast since 2015, finally I’m going to fulfill dream by completing Masters in Data Science from Bellevue University - 2021. 

Apart from my regular work, I love to play volleyball and tennis.


