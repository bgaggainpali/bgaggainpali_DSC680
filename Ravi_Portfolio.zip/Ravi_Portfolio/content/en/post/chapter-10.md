---
date: 2019-12-15T11:25:05-04:00
description: "Python"
#featured_image: "/images/esmeralda.jpg"
#tags: []
title: "Project X: Python"
#disable_share: false
---
Python is an interpreted, high-level and general-purpose programming language. Python's design philosophy emphasizes code readability with its notable use of significant indentation. Its language constructs and object-oriented approach aim to help programmers write clear, logical code for small and large-scale projects 

Using Python, worked on several tasks which can show the capabilities and features of the python programming.



[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC510)
