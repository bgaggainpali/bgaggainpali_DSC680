---
date: 2021-02-07T11:15:58-04:00
description: "Air Travel & Safety"
#featured_image: ""
#tags: []
title: "Project V: Air Travel & Safety"
---

Air travel is one of the important models of the transportation and it has made many journeys possible. Many places, where the road journey is not possible, air travel opened the options to explore. With journey on ships which could take weeks and months, we can reach in few hours using air travel.

With one recent incident, we see the speculation all over the social media people showing stats of all the airline accidents and many discussions about the reliability of the total air travel and exploring the options of how to avoid air travel.  I strongly feel the air travel is more safer and reliable modes of transportation. And waned to present the stats on how the number of incidents reduced over last few years. Just not to base on one incident and speculate about whole industry.

{{< figure src="/images/Air_Travel_Safety.jpg">}}

[Link to Github Repository](https://github.com/bgaggainpali/DSC640_Data_Presentation_And_Visualization)
