---
date: 2020-05-10T11:25:05-04:00
description: "Diamonds"
#featured_image: "/images/esmeralda.jpg"
#tags: []
title: "Project VIII: Diamonds"
#disable_share: false
---
With the Stock market fall because of the Corona virus situation, I was surprised to see how the gold and diamonds prices are rising. I guess people are looking for safe investments, which is causing the prices go high. This generally happens when the markets are uncertain.

I got interested to do some data analysis regarding the diamonds. As I do not have much information about diamonds, I search about the data and found a dataset provided by Shivam Agarwal in kaggle. This dataset contains a lot of details and properties of the diamond like the price, shape, and other attributes.



[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC530)
