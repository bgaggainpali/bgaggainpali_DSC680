---
date: 2020-11-14T11:25:05-04:00
description: "Mental Health Prediction"
#featured_image: "/images/esmeralda.jpg"
#tags: []
title: "Project VI: Mental Health Prediction"
#disable_share: false
---
As recently I have received a form from my employer to complete the survey on Mental health conditions. Because of the Corona Virus situation, everyone is working remotely and restricting themselves not to go out other than to get groceries. Spending most of the time at home, now a days leading to depression and other mental health issue. 

I would like to explore to see what factors are influencing the mental health conditions by relating different factors variables and find which categories of people are more effected.

{{< figure src="/images/Mental_Health_Prediction.jpg">}}

[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC550)
