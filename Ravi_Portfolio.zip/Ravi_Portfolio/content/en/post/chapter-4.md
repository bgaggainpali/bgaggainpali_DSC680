---
date: 2021-01-07T11:14:48-04:00
description: "Telecom Customer Churn"
#featured_image: ""
#tags: ["scene"]
title: "Project IV: Telecom Customer Churn"
---
Customer churn is a major problem and one of the most important concerns for every company. Retaining an existing customer is many times more effective thanks gaining new customers. Generally, people only switch to a different company only when the service is not to the level of expectation in one or the other factor when compared to competitors, more than getting attracted to the specials and offers which are offered by the other companies. 

As customer churn directly effects the revenues of the companies, companies are seeking to develop means to predict potential customer to churn. Therefore, finding factors that increase customer churn is important to take necessary actions to reduce this churn and retain the customers.

{{< figure src="/images/Telecom_Customer_Churn.jpg">}}

[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC630)
