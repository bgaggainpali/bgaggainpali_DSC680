---
date: 2021-04-20T11:00:59-04:00
description: "Credit Card Default Prediction"
#featured_image: ""
#tags: []
title: "Project II: Credit Card Default Prediction"
---

In financial industry, banks are playing important role in challenging times like now, with COVID pandemic across the globe. People are losing jobs and financial institutions are facing more delinquency rate on credit card loans.  The increase in delinquency rate will result in significant financial loss to commercial banks.  It is very critical for lending institutions like banks to have a prediction model to be able to predict customers for credit card default. 

I have selected the topic, as I was interested in knowing the variables which influence the credit card default key factors. As I explore more about the domain, I understand that it’s not same set of rules which is being used across domain and each different banks and credit unions are based on different credit score calculation structure when approving credit cards, but the factors which influence the default are same.

{{< figure src="/images/Credit_Card_Default_Prediction.jpeg">}}

[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC680)
