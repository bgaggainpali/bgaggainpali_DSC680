---
date: 2021-05-03T11:13:32-04:00
description: "Predicting Churn for Bank Customers"
#featured_image: ""
#tags: []
title: "Project III: Predicting Churn for Bank Customers"
---

In financial industry, banks are playing important role in challenging times like now, with COVID pandemic across the globe. People are losing jobs and financial institutions are facing more Customer churn in Bank Accounts.  The increase in Customer Churn rate will result in significant financial loss to commercial banks.  It is very critical for lending institutions like banks to have a prediction model to be able to predict customers churn to better serve the customers and reduce the churn.

We could see many people close their bank accounts where they cannot maintain minimum balance in the account with the current pandemic Covid situation and it would impact financial budgeting for banks as it has limited assets which can handle the churn until certain extent only, so finding out the customers who are possibly to fall in the churn category will help banks to mitigate and balance the risk of the churn customers. In this paper I will try to predict to find, who are possibly to fall in as churn category and identify the customers to reduce this risk factor of bank to better serve the customers.

{{< figure src="/images/Predicting_Churn_for_Bank_Customers.jpg">}}

[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC680)
