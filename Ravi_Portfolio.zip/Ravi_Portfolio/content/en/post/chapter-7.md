---
date: 2020-10-14T11:25:05-04:00
description: "Monroe County Crash Data"
#featured_image: "/images/esmeralda.jpg"
#tags: []
title: "Project VII: Monroe County Crash Data"
#disable_share: false
---
I have selected the ‘Monroe County Crash Data’ for the final project as part of the course. This dataset is the list of all the car crash or accidents happened in the county from 2003 to 2015. I have considered the data for the year 2015 for analysis as part of CSV file (one of the data sources). Retrieved the Holiday list from the give website to get the list of the holidays for the year of 2015 (source website data). Using API to the Weather details to get the weather conditions of the county for the whole year of 2015 (source API data). Using data from 3 data sources, I tried to find the trend of the car accidents across the year to see if the Holiday season or the weather conditions are relating to the increase or decrease of the car accidents.

{{< figure src="/images/Monroe_County_Crash_Data.jpg">}}

[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC540)
