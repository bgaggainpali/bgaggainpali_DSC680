---
date: 2021-03-10T10:58:08-04:00
description: "Loan Approval Prediction Process"
#featured_image: "/images/Pope-Edouard-de-Beaumont-1844.jpg"
#tags: ["scene"]
title: "Project I: Loan Approval Prediction Process"
---

In financial industry, deciding on a loan application, whether to approve or not is a two-edged sword.  Bank should not lose business by denying a legitimate customer, who can repay.  Also, it should not approve loan to in-eligible customer.  Banks are playing important role in challenging times like now, with COVID pandemic across the globe.

With the enhancement in the banking sector lots of people are applying for bank loans but the bank has its limited assets which it has to grant to limited people only, so finding out to whom the loan can be granted which will be a safer option for the bank is a typical process. In this paper we try to predict the customer, whether he is eligible for the loan approval and to reduce this risk factor of bank efforts and assets.

{{< figure src="/images/Loan_Approval_Prediction_Process.jpeg">}}

[Link to Github Repository](https://github.com/bgaggainpali/bgaggainpali_DSC680)


